# workaround for now, because gRPC refuses to start from python otherwise
import os
os.environ["PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION"]="python"

# Inside a matafan term:
#   > python -m pip install --upgrade pip
#   > python -m pip install grpcio==1.26.0
#   > python -m pip install grpcio-tools==1.26.0
#   > python -m pip install wheel
#     python setup.py bdist_wheel
# https://jupyterlite.readthedocs.io/en/latest/quickstart/standalone.html
# a quick way to have a custom site is stored in this link
# https://prog.world/how-to-embed-a-jupyter-notebook-on-any-website/
# https://jupyterlite-repl-prerun.readthedocs.io/en/latest/

from dataclasses import dataclass
from enum import Enum
import grpc
import sys
import sysmlp_pb2
import sysmlp_pb2_grpc
from typing import Any, Callable, ClassVar, Dict, List, Optional, Tuple
import xml.etree.ElementTree as ET



__doc__ = """Please complete me"""

def __dir__() -> List[str]:
    # Restricts what is visible if the end user class dir() on this module.
    # By convention for this file, if it is documented with """ """, therefore it is a public
    # symbol and shall appear in the list returned by __dir__
    return [
        "__doc__",
        "RectF",
        "Point2dF",
        "SizeF",
        "Color",
        "Multiplicity",
        "CoordinateSystem",
        "FeatureDirection",
        "Kind",
        "Element",
        "Apy"
    ]


def useStub(f):
    # A dummy decorator to help distinguish between functions which will perform
    # a request and those which will not.
    return f


###################################################################################################
# Warning, the code in this section relies heavily on the current implementation of MB::MODEL
# Any change in MB::MODEL shall be replicated here.
# This is also a "best effort" approach to deal with the different data types between C++
# and python
###################################################################################################
# BEGIN SECTION
###################################################################################################
def _makeEnum(name: str, name2StringValues: Dict[str, str]) -> Enum:
    newClass: Enum = Enum(name, list(name2StringValues.keys()))

    def toString(self) -> str:
        key: str = Enum.__str__(self).split(".")[-1]
        return name2StringValues[key]

    def fromString(value: str) -> Any:
        key: str = [k for k, v in name2StringValues.items() if v == value][0]
        return newClass[key]

    newClass.fromString = fromString
    newClass.toString = toString
    return newClass


@dataclass
class RectF:
    """Represents a rectangle. (x,y) are the "top left" position"""
    x: float = 0.0
    y: float = 0.0
    width: float = 0.0
    height: float = 0.0

    def _toMbmString(self) -> str:
        return f"origin({self.x} {self.y});size({self.width} {self.height})"

    @staticmethod
    def _fromMbmString(value: str) -> 'RectF':
        if value == "null":
            return RectF(0.0, 0.0, 0.0, 0.0)

        originAndSize: List[str] = value.split(";")
        if len(originAndSize) != 2:
            return RectF(0.0, 0.0, 0.0, 0.0)

        origin: str = originAndSize[0].replace("origin(", "")[:-1]
        size: str = originAndSize[1].replace("size(", "")[:-1]
        xy: List[str] = origin.split(" ")
        wh: List[str] = size.split(" ")
        if len(xy) != 2 or len(wh) != 2:
            return RectF(0.0, 0.0, 0.0, 0.0)
        return RectF(float(xy[0]), float(xy[1]), float(wh[0]), float(wh[1]))

@dataclass
class Point2dF:
    """Represents a planar point."""
    x: float = 0.0
    y: float = 0.0

    def _toMbmString(self) -> str:
        return f"{self.x} {self.y}"

    @staticmethod
    def _fromMbmString(value: str) -> 'Point2dF':
        if value == "null":
            return Point2dF(0.0, 0.0)

        values: List[str] = value.split(" ")
        if len(values) != 2:
            return Point2dF(0.0, 0.0)

        return Point2dF(float(values[0]), float(values[1]))

@dataclass
class SizeF:
    """Represents a size"""
    width: float = 0.0
    height: float = 0.0

    def _toMbmString(self) -> str:
        return f"{self.width} {self.height}"

    @staticmethod
    def _fromMbmString(value: str) -> 'SizeF':
        if value == "null":
            return SizeF(0.0, 0.0)

        values: List[str] = value.split(" ")
        if len(values) != 2:
            return SizeF(0.0, 0.0)

        return SizeF(float(values[0]), float(values[1]))

@dataclass
class Color:
    """Represents a RGBA color"""
    red: int = 0
    green: int = 0
    blue: int = 0
    alpha: int = 255

    def __clamp(self, value: int) -> int:
        return min(255, max(0, value))

    @property
    def red(self) -> int:
        return self.red

    @red.setter
    def red(self, value: int) -> None:
        self.red = self.__clamp(value)

    @property
    def green(self) -> int:
        return self.green

    @green.setter
    def green(self, value: int) -> None:
        self.green = self.__clamp(value)

    @property
    def blue(self) -> int:
        return self.blue

    @blue.setter
    def blue(self, value: int) -> None:
        self.blue = self.__clamp(value)

    @property
    def alpha(self) -> int:
        return self.alpha

    @alpha.setter
    def alpha(self, value: int) -> None:
        self.alpha = self.__clamp(value)

    def _toMbmString(self) -> str:
        def toHex(value: int) -> str:
            return ("{:02x}".format(value)).upper()
        return f"#{toHex(self.red)}{toHex(self.green)}{toHex(self.blue)}{toHex(self.alpha)}"

    @staticmethod
    def _fromMbmString(value: str) -> 'Color':
        if value == "null" or not value.startswith("#") or len(value) != 9:
            return Color(0, 0, 0, 255)

        def fromHex(first: int, last: int) -> int:
            text: str = "0x" + value[first:last + 1]
            return int(text, 16)

        return Color(fromHex(1, 2), fromHex(3, 4), fromHex(5, 6), fromHex(7, 8))

@dataclass
class Multiplicity:
    """Represents a multiplicity. lower == upper implies the multiplicity has a "single" value"""
    lower: int = 1
    upper: int = 1
    STAR_WILDCARD: ClassVar[int] = -1

    def __clamp(self, value: int) -> int:
        return max(Multiplicity.STAR_WILDCARD, value)

    def __setRange(self, lower: int, upper: int) -> None:
        lowerArranged: int = self.__clamp(lower)
        upperArranged: int = self.__clamp(upper)
        if lowerArranged == upperArranged:
            self.lower = lowerArranged
            self.upper = upperArranged
        elif lowerArranged == Multiplicity.STAR_WILDCARD:
            self.lower = upperArranged
            self.upper = lowerArranged
        elif upperArranged == Multiplicity.STAR_WILDCARD:
            self.lower = lowerArranged
            self.upper = upperArranged
        else:
            self.lower = min(lowerArranged, upperArranged)
            self.upper = max(lowerArranged, upperArranged)

    @property
    def lower(self) -> int:
        return self.lower

    @lower.setter
    def lower(self, value: int) -> None:
        self.__setRange(value, self.upper)

    @property
    def upper(self) -> int:
        return self.upper

    @upper.setter
    def upper(self, value: int) -> None:
        self.__setRange(self.lower, value)

    def _toMbmString(self) -> str:
        def toString(value: int) -> str:
            if value == Multiplicity.STAR_WILDCARD:
                return "*"
            else:
                return str(value)

        if self.lower == self.upper:
            return toString(self.lower)
        else:
            return f"{toString(self.lower)}..{toString(self.upper)}"

    @staticmethod
    def _fromMbmString(value: str) -> 'Multiplicity':
        def fromString(value: str) -> int:
            return Multiplicity.STAR_WILDCARD if value == "*" else int(value)

        if value == "null":
            return Multiplicity(0, 0)

        values: List[str] = value.split("..")
        if len(values) == 1:
            bound: int = int(values[0])
            return Multiplicity(bound, bound)
        elif len(values) == 2:
            return Multiplicity(int(values[0]), int(values[1]))
        else:
            return Multiplicity(0, 0)


CoordinateSystem = _makeEnum("CoordinateSystem", {
    "AscendingY" : "AscendingY",
    "DescendingY" : "DescendingY"
})

FeatureDirection = _makeEnum("FeatureDirection", {
    "IN" : "in",
    "INOUT" : "inout",
    "OUT" : "out",
    "UNSET" : "unset"
})

Kind = _makeEnum("Kind", {
    "Comment" : "Comment",
    "Documentation" : "Documentation",
    "TextualRepresentation" : "TextualRepresentation",
    "Note" : "Note"
})


def _stringToStringList(value: str) -> List[str]:
    root: ET.Element = ET.fromstring(value)
    return [c.text for c in root]

_stringToValueMap = {
    # std::monostate
    # ignored for now, and not supposed to happen
    0  : lambda x:None,
    1  : int,                                  # int
    2  : lambda x:x,                           # std::string
    3  : lambda x:False if x == "0" else True, # bool
    4  : float,                                # double
    5  : float,                                # float
    6  : FeatureDirection.fromString,          # FeatureDirection
    7  : lambda x:x,                           # std::optional<std::string>
    8  : Kind.fromString,                      # Kind
    9  : CoordinateSystem.fromString,          # CoordinateSystem
    10 : Point2dF._fromMbmString,              # Point2dF
    11 : SizeF._fromMbmString,                 # SizeF
    12 : RectF._fromMbmString,                 # RectF

    # std::list<Point2dF>
    13 : lambda x:[Point2dF.fromString(a) for a in x.split("|") if a != ""],
    14 : _stringToStringList,                                  # std::list<std::string>
    15 : lambda x:x,                                           # std::filesystem::path
    16 : _stringToStringList,                                  # std::list<std::filesystem::path>
    17 : lambda x:[float(a) for a in x.split("|") if a != ""], # std::vector<double>
    18 : Color._fromMbmString,                                 # Color
    19 : lambda x:max(0, int(x)),                              # unsigned long
    20 : Multiplicity._fromMbmString,                          # Multiplicity

    # Any
    # ignored for now, need to decide how to deal with it.
    21 : lambda x:None
}

def _FromVariant(message: sysmlp_pb2.Variant) -> Any:
    assert(not message.isNull)
    return _stringToValueMap[message.value.typeIndex](message.value.stringValue)


def _pointsToString(points: List[Point2dF]) -> str:
    text: str = ""
    for point in points:
        text += point._toMbmString() + "|"
    return text

def _doublesToString(values: List[float]) -> str:
    text: str = ""
    for value in values:
        text += str(value) + "|"
    return text

# workaround for CDATA found here:
# https://stackoverflow.com/questions/174890/how-to-output-cdata-using-elementtree
def CDATA(text=None):
    element = ET.Element('![CDATA[')
    element.text = text
    return element

def _serialize_xml(write, elem, qnames, namespaces, short_empty_elements, **kwargs):
    if elem.tag == '![CDATA[':
        write("<{}{}]]>".format(elem.tag, elem.text))
        if elem.tail:
            write(_escape_cdata(elem.tail))
    else:
        return ET._original_serialize_xml(write, elem, qnames, namespaces,short_empty_elements, **kwargs)

def _stringListToString(values: List[str]) -> str:
    ET._original_serialize_xml = ET._serialize_xml
    ET._serialize_xml = ET._serialize['xml'] = _serialize_xml

    root: ET.Element = ET.Element("values")
    for value in values:
        element: ET.Element = ET.SubElement(root, "value")
        element.append(CDATA(value))
        
    result: str = ET.dump(root)
    ET._serialize_xml = ET._serialize['xml'] = ET._original_serialize_xml
    return result

def _anyListToString(listObject: list) -> Tuple[int, Callable]:
    if not listObject:
        return (2, str)

    firstType = type(listObject[0])
    for e in listObject:
        if firstType != type(e):
            return (2, str)

    if firstType is Point2dF:
        return (13, _pointsToString)
    elif firstType is str:
        return (14, _stringListToString)
    elif firstType is float:
        return (17, _doublesToString)
    return (2, str)

# Python does not offer distinction between signed and unsigned integers, or single/double precision
# float. std::optional<std::string> is represented by "None", meaning that we've lost the real type
# and cannot deduce that this particular None was a str.
# The value on this dict is a callable returning a tuple with 2 elements:
#   - The type index
#   - The value of the variant converted to a string
_typeToIndexMap = {
    int : lambda v:(1, str(v)),
    str : lambda v:(2, str(v)),
    bool : lambda v:(3, lambda x : "0" if v is False else "1"),
    float : lambda v:(4, str(v)),
    FeatureDirection : lambda v:(6, FeatureDirection.toString(v)),
    Kind : lambda v:(8, Kind.toString(v)),
    CoordinateSystem : lambda v:(9, CoordinateSystem.toString(v)),
    Point2dF : lambda v:(10, Point2dF._toMbmString(v)),
    SizeF : lambda v:(11, SizeF._toMbmString(v)),
    RectF : lambda v:(12, RectF._toMbmString(v)),
    list : _anyListToString,
    Color : lambda v:(18, Color._toMbmString(v)),
    Multiplicity : lambda v:(20, Multiplicity._toMbmString(v))
}

def _ToVariant(value: Any) -> sysmlp_pb2.Variant:
    assert(value is not None)
    index, stringValue = _typeToIndexMap[type(value)](value)
    return sysmlp_pb2.Variant(stringValue=stringValue, typeIndex=index)
###################################################################################################
# END SECTION
###################################################################################################


class Element(object):
    """Represents an element from the left tree view"""
    __slots__ = ("__stub", "__fullIdentifier", "__tabId")

    def __init__(self, stub, fullIdentifier: str, tabId: str) -> None:
        assert(stub is not None)
        assert(tabId != "")
        assert(fullIdentifier != "")

        # a Stub object instance from gRPC, with the methods to invoke in order
        # to send requests
        self.__stub = stub

        # From the client side, a MB::MODEL object will be nothing more than its full identifier
        # because this information is enough to identify the object on the server (assuming the object
        # is still loaded in memory)
        self.__fullIdentifier = fullIdentifier

        # This identifier is there to allow to know to which "SYSMLP Project tab" the request
        # shall be addressed.
        # Basically, if there is one gRPC server per tab, this identifier is not really required.
        # However, if there is only one gRPC server which is dispatching requests to the proper tab,
        # this identifier will be helpful to know to which tab the request shall be forwarded.
        self.__tabId = tabId

    def __toMessage(self) -> sysmlp_pb2.Self:
        header = sysmlp_pb2.RequestHeader(projectIdentifier=self.__tabId)
        return sysmlp_pb2.Self(header=header, fullIdentifier=self.__fullIdentifier)

    def __fromMessage(self, message: sysmlp_pb2.ElementOrNull) -> 'Optional[Element]':
        if message.isNull:
            return None
        else:
            return self.__makeElement(message.fullIdentifier)

    def __makeElement(self, fullIdentifier: str) -> 'Element':
        return Element(self.__stub, fullIdentifier, self.__tabId)

    def __makeRequest(self, classObject: Any, **kwargs) -> Any:
        #@brief Allows to factorize the construction of a grpc message for the "argument(s)"
        #of the rpc call.
        #@warning It always assume that the first argument is "self" of message type Self
        #@details Further required members could be passed as part of **kwargs. For example:
        #      message MyMessage {
        #         Self self = 1;
        #         string extraName = 2; // <<--------------- This part is an extra field.
        #      }
        #self.__makeRequest(MyMessage, extraName="toto")
        return classObject(self=self.__toMessage(), **kwargs)

    def _fullIdentifier(self) -> str:
        # Returns the internal fullIdentifier. This data is cached, so it
        # might not reflect the exact situation on the server side.
        return self.__fullIdentifier


    @useStub
    def isExpired(self) -> bool:
        """Returns True if the client object still exists on the server side."""
        return self.__stub.ELEMENT_isExpired(self.__toMessage()).value

    @useStub
    def identifier(self) -> str:
        """
        Returns the identifier of this element.
        Keep in mind that an identifier is only unique among this element siblings.
        """
        return self.__stub.ELEMENT_identifier(self.__toMessage()).value

    @useStub
    def className(self) -> str:
        """Returns the class name of the element"""
        return self.__stub.ELEMENT_className(self.__toMessage()).value

    @useStub
    def parent(self) -> 'Optional[Element]':
        """Returns the parent element, if any. If there is none, None will ve returned"""
        response = self.__stub.ELEMENT_parent(self.__toMessage())
        return self.__fromMessage(response)

    @useStub
    def removeSubElement(self, element: 'Element') -> None:
        """Remove @b element from the hierarchy of @b self"""
        if element is None:
            return
        message = self.__makeRequest(sysmlp_pb2.SelfWithStringArgument,
                                     stringValue=element.identifier())
        self.__stub.ELEMENT_removeSubElement(message)

    @useStub
    def subElements(self) -> 'List[Element]':
        """Returns all the sub elements available for @b self."""
        response = self.__stub.ELEMENT_subElements(self.__toMessage())
        return [self.__makeElement(i) for i in response.values]

    @useStub
    def subElement(self, identifier: str) -> 'Optional[Element]':
        """Fetches the sub element with identifier @b identifier, if it exists."""
        message = self.__makeRequest(sysmlp_pb2.SelfWithStringArgument, stringValue=identifier)
        response = self.__stub.ELEMENT.subElement(message)
        return self.__fromMessage(response)

    @useStub
    def makeSubElement(self, className: str, identifier: str, name: str) -> 'Optional[Element]':
        """Adds a new sub element into the hierarchy"""
        message = self.__makeRequest(sysmlp_pb2.MakeSubElementArgs,
                                     className=className,
                                     identifier=identifier,
                                     name=name)

        response = self.__stub.ELEMENT_makeSubElement(message)
        return self.__fromMessage(response)

    @useStub
    def propertyNames(self) -> List[str]:
        """Returns a list of all the property names for this element"""
        return self.__stub.ELEMENT_propertyNames(self.__toMessage()).values

    @useStub
    def referencePropertyNames(self) -> List[str]:
        """Returns a list of all the reference property names for this element"""
        return self.__stub.ELEMENT_referencePropertyNames(self.__toMessage()).values

    @useStub
    def property(self, name: str) -> Optional[Any]:
        """Fetches the value of a property named @b name"""
        message = self.__makeRequest(sysmlp_pb2.SelfWithStringArgument, stringValue=name)
        response = self.__stub.ELEMENT_property(message)
        if response.wasFound:
            return _FromVariant(response.value)
        else:
            return None

    @useStub
    def referenceProperty(self, name: str) -> 'Optional[Element]':
        """Fetches the element of a reference property named @b name"""
        message = self.__makeRequest(sysmlp_pb2.SelfWithStringArgument, stringValue=name)
        response = self.__stub.ELEMENT_referenceProperty(message)
        return self.__fromMessage(response)

    @useStub
    def setProperty(self, name: str, value: Any) -> None:
        """
        Sets the value of the property named @b name. If the value is not the proper
        type (or if @b name is unknown), the function does nothing.
        """
        if value is None:
            return

        message = self.__makeRequest(sysmlp_pb2.SetPropertyArgs, value=_ToVariant(value), name=name)
        self.__stub.ELEMENT_setProperty(message)

    @useStub
    def setReferenceProperty(self, name: str, value: 'Optional[Element]') -> None:
        """Allows to set the reference property @b name with @b value. None is an acceptable value."""
        fullIdentifier = "" if value is None else value._fullIdentifier()
        message = self.__makeRequest(sysmlp_pb2.SetReferencePropertyArgs,
                                     fullIdentifier=fullIdentifier,
                                     name=name)

        self.__stub.ELEMENT_setReferenceProperty(message)

    @useStub
    def stereotypeNames(self) -> List[str]:
        """Returns all the stereotype names, which are applied to @b self"""
        return self.__stub.ELEMENT_stereotypeNames(self.__toMessage()).values

    @useStub
    def addStereotype(self, stereotypeName: str) -> None:
        """
        Adds the stereotype named @b name to @b self. If the stereotype is not applicable or
        already applied, this function does nothing.
        """
        message = self.__makeRequest(sysmlp_pb2.SelfWithStringArgument, stringValue=stereotypeName)
        self.__stub.ELEMENT_addStereotype(message)

    @useStub
    def removeStereotype(self, stereotypeName: str) -> None:
        """Removes the stereotype named @b stereotypeName from @b self"""
        message = self.__makeRequest(sysmlp_pb2.SelfWithStringArgument, stringValue=stereotypeName)
        self.__stub.ELEMENT_removeStereotype(message)


class Apy(object):
    """
    The base object to manipulate the SYSMLP Project tab. It allows mainly to:
       - Access the Project object (an instance of Element).
       - Do some basic manipulation of the tab UI.
    """
    __slots__ = ("__project", "__stub", "__tabId")

    def __init__(self, initialization: str) -> None:
        # The argument initialization shall be a base64 string, of the required data, well formatted.

        import base64
        # Decode in utf-8 because the identifier could contain non ascii character.
        data: str = base64.b64decode(initialization.encode("ascii")).decode("utf-8")

        separatorIndex: int = data.find(";")
        assert(separatorIndex != -1)
        port: str = data[0:separatorIndex]
        self.__tabId = data[separatorIndex+1:]

        channel = grpc.insecure_channel("localhost:" + port)
        self.__stub = sysmlp_pb2_grpc.apyStub(channel)
        self.__project = Element(self.__stub, self.__tabId, self.__tabId)


    def __makeHeader(self) -> sysmlp_pb2.RequestHeader:
        return sysmlp_pb2.RequestHeader(projectIdentifier=self.__tabId)

    def __makeHeaderWithTarget(self, element: Element) -> sysmlp_pb2.RequestWithTarget:
        return sysmlp_pb2.RequestWithTarget(header=self.__makeHeader(),
                                            fullIdentifier=element._fullIdentifier())


    @property
    def project(self) -> Element:
        """Returns the SYSMLP project entity"""
        return self.__project


    @useStub
    def undo(self) -> None:
        """Triggers the "undo" action"""
        self.__stub.GUI_undo(self.__makeHeader())

    @useStub
    def redo(self) -> None:
        """Triggers the "redo" action"""
        self.__stub.GUI_redo(self.__makeHeader())

    @useStub
    def save(self) -> None:
        """Triggers the save of the current tab."""
        self.__stub.GUI_save(self.__makeHeader())

    @useStub
    def openDiagram(self, diagram: Element) -> None:
        """Opens the diagram tab for @b diagram (if it is possible to do so)."""
        if diagram is not None:
            self.__stub.GUI_openDiagram(self.__makeHeaderWithTarget(diagram))

    @useStub
    def closeDiagram(self, diagram: Element) -> None:
        """Closes the diagram tab of @b diagram (if it is possible to do so)."""
        if diagram is not None:
            self.__stub.GUI_closeDiagram(self.__makeHeaderWithTarget(diagram))

    @useStub
    def openProperties(self, element: Element) -> None:
        """
        Open the properties dialog for @ element (assuming it is possible to do so) and
        waits until the user closes it.
        """
        if element is not None:
            self.__stub.GUI_openProperties(self.__makeHeaderWithTarget(element))
